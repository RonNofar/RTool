import RTool.prototype.tos

__all__ = ["tos"]
