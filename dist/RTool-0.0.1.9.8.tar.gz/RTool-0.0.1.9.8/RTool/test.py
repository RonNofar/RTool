'''
this is a hierarchy test
'''

import sys, os, time
rootPath = os.path.dirname(os.path.realpath(__file__))
sys.path.append(os.path.split(rootPath)[0])

import RTool.prototype
'''
import RTool.util.importer as i

i.ImportHandler(["Cython"])
'''

